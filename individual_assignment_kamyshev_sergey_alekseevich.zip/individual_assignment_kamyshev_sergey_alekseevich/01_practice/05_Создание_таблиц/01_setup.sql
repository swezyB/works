PRAGMA foreign_keys = ON;

CREATE TABLE category (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE product (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    price REAL NOT NULL CHECK (price > 0),
    category_id INTEGER REFERENCES category(id),
    created TEXT NOT NULL DEFAULT (date('now'))
);

CREATE TABLE supplier (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL UNIQUE
);

CREATE TABLE shipment (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL REFERENCES product(id),
    supplier_id INTEGER NOT NULL REFERENCES supplier(id),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    date TEXT NOT NULL DEFAULT CURRENT_DATE CHECK (date >= '2020-01-01'),
    UNIQUE (product_id, supplier_id)
);

INSERT INTO category (name) VALUES ('Еда'), ('Быт');
INSERT INTO product (name,price,category_id) VALUES
('Хлеб',40,1),('Молоко',60,1),('Мыло',80,2),('Сыр',200,1);
INSERT INTO supplier (name,phone,email) VALUES
('ООО Продукты','111-11-11','food@example.test'),
('ООО Хозтовары','222-22-22','home@example.test'),
('ИП Поставка','333-33-33','supply@example.test');
INSERT INTO shipment (product_id,supplier_id,quantity) VALUES
(1,1,100),(2,1,50),(3,2,30),(4,3,10);
