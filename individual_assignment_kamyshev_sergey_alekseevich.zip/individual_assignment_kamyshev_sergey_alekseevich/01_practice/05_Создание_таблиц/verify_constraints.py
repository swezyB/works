"""Проверка ограничений CREATE TABLE из практической работы 05."""
import sqlite3, json
from pathlib import Path
p=Path(__file__).with_name('practice.db')
c=sqlite3.connect(p)
c.execute('PRAGMA foreign_keys=ON')
checks=[]
def must_fail(label, sql, params=()):
    try:
        c.execute(sql,params)
    except sqlite3.IntegrityError as e:
        checks.append({'check':label,'result':'ошибка ожидаема','detail':str(e)})
        c.rollback()
    else:
        raise AssertionError(label+' — ограничение не сработало')
must_fail('CHECK price > 0', "INSERT INTO product(name,price,category_id) VALUES('Тест нулевой цены',0,1)")
must_fail('UNIQUE category.name', "INSERT INTO category(name) VALUES('Еда')")
must_fail('FOREIGN KEY product.category_id', "INSERT INTO product(name,price,category_id) VALUES('Тест FK',10,99)")
must_fail('CHECK shipment.quantity > 0', "INSERT INTO shipment(product_id,supplier_id,quantity) VALUES(1,2,0)")
must_fail('UNIQUE shipment(product_id,supplier_id)', "INSERT INTO shipment(product_id,supplier_id,quantity) VALUES(1,1,1)")
must_fail('CHECK shipment.date >= 2020-01-01', "INSERT INTO shipment(product_id,supplier_id,quantity,date) VALUES(1,2,1,'2019-12-31')")
c.execute("INSERT INTO product(name,price,category_id) VALUES('Проверка корректной ссылки',10,1)")
checks.append({'check':'Корректный FOREIGN KEY category_id=1','result':'вставка успешна'})
c.rollback()
assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
assert c.execute('PRAGMA foreign_key_check').fetchall()==[]
Path(__file__).with_name('constraint_checks.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
c.close()
print('Все проверки ограничений выполнены.')
