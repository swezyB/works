-- 1. Созданные категории
SELECT id,name FROM category ORDER BY id;

-- 2–3. Товары с категорией и положительной ценой
SELECT p.id,p.name,p.price,c.name AS category FROM product p LEFT JOIN category c ON c.id=p.category_id ORDER BY p.id;

-- 4. Поставщики
SELECT id,name,phone,email FROM supplier ORDER BY id;

-- 5–8. Поставки и связи с товаром и поставщиком
SELECT sh.id,p.name AS product,s.name AS supplier,sh.quantity,sh.date FROM shipment sh JOIN product p ON p.id=sh.product_id JOIN supplier s ON s.id=sh.supplier_id ORDER BY sh.id;

-- 7. Проверка даты по умолчанию
SELECT id,date=CURRENT_DATE AS date_is_today FROM shipment ORDER BY id;

-- 8. Составной UNIQUE в shipment
SELECT name,"unique" FROM pragma_index_list('shipment') ORDER BY seq;

-- Проверка ссылочной целостности
PRAGMA foreign_key_check;
